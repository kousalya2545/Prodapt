let marks = [85,43,76,91,38,67,55,29,80,49];
let pass =0
let fail =0
for (let i = 0; i < marks.length; i++){
    if(marks[i]<50){
        console.log("Student "+i+": "+marks[i]+" - Fail");
        fail++;
    }
    else{
        console.log("Student "+i+": "+marks[i]+" - Pass");
        pass++
    }
}
console.log("Total passed: "+pass);
console.log("total Failed: "+fail);
