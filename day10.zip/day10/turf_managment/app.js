import { getBooking } from "./api/getBooking.js";

async function main() {

    console.log("Fetching latest bookings from JSON Server...\n");

    const bookings = await getBooking();

    console.table(bookings);

}

main();