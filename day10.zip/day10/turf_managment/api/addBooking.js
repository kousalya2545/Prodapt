export async function addBooking(booking)
{
    const response = await fetch("https://localhost:3000/bookings",{
        method: "POST",
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify(booking)

    });
    return await response.json();

if(!response.ok){
    console.log("Error booking")
}
const booking = await response.json()
console.log("Booking added sucessfully")
return booking
}