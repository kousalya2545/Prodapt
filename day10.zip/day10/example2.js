//Primitive Data types
let name = "Alice";
let age = 25;
let isActive = true;
let salary = null;
let address;
let id = Symbol("id")  //Symbol
let big = 123456789n;   //BigInt

//Non Primitive
let Student = {
    name: "John",
    age: 22
};
let colors = ["Red","Blue"];
function greet()
{
    console.log("Hello")
}
greet()