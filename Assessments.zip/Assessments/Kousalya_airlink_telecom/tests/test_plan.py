import unittest
from data.datastore import DATASTORE  # type: ignore
from models.plan import Prepaid, Postpaid, DataPack  # type: ignore

class TestPlan(unittest.TestCase):
    def setUp(self):
        DATASTORE["subscribers"].clear()
        DATASTORE["plans"].clear()
        DATASTORE["connections"].clear()

    def test_bill_overriding(self):
        prepaid = Prepaid("Saver", "1GB", 200)
        postpaid = Postpaid("Pro", "2GB", 500)
        datapack = DataPack("Data", "3GB", 300)

        self.assertEqual(prepaid.bill(2), 400)
        self.assertAlmostEqual(postpaid.bill(2), 1180.0)
        self.assertEqual(datapack.bill(2), 650)

    def test_price_validation(self):
        with self.assertRaises(ValueError):
            Prepaid("Zero Plan", "1GB", 0)
        with self.assertRaises(ValueError):
            Prepaid("Negative Plan", "1GB", -50)

if __name__ == "__main__":
    unittest.main()