import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from data.datastore import DATASTORE  # type: ignore[import]
from data.seed_data import seed_database  # type: ignore[import]
from services.connection_service import ConnectionService  # type: ignore[import]

class TestConnection(unittest.TestCase):
    def setUp(self):
        DATASTORE["subscribers"].clear()
        DATASTORE["plans"].clear()
        DATASTORE["connections"].clear()
        seed_database()
        self.service = ConnectionService()

    def test_activate_success(self):
        conn = self.service.activate("SUB01", "PRE-101", 2)
        self.assertIsNotNone(conn)
        self.assertEqual(conn.status, "ACTIVE")
        self.assertIn(conn.connection_id, DATASTORE["connections"])
        sub = DATASTORE["subscribers"]["SUB01"]
        self.assertEqual(sub.balance, 1600.0)

    def test_ineligible_blocked(self):
        conn = self.service.activate("SUB03", "PRE-101", 1)
        self.assertIsNone(conn)
        self.assertEqual(len(DATASTORE["connections"]), 0)

if __name__ == "__main__":
    unittest.main()