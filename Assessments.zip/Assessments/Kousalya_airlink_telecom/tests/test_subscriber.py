import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from datastore import DATASTORE  # type: ignore[import]
from subscriber_service import SubscriberService  # type: ignore[import]

class TestSubscriber(unittest.TestCase):
    def setUp(self):
        DATASTORE["subscribers"].clear()
        DATASTORE["plans"].clear()
        DATASTORE["connections"].clear()
        self.service = SubscriberService()

    def test_add_subscriber(self):
        sub = self.service.add_subscriber("SUB01", "Karthik", 26, "9876543210", "AAD-4821-9034", 2000)
        self.assertIn("SUB01", DATASTORE["subscribers"])
        self.assertEqual(DATASTORE["subscribers"]["SUB01"].name, "Karthik")

    def test_balance_encapsulation(self):
        sub = self.service.add_subscriber("SUB01", "Karthik", 26, "9876543210", "AAD-4821-9034", 100)
        result = sub.deduct(200)
        self.assertFalse(result)
        self.assertEqual(sub.balance, 100)
        with self.assertRaises(AttributeError):
            _ = sub.__balance

if __name__ == "__main__":
    unittest.main()