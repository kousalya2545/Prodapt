from data.datastore import DATASTORE

def is_eligible(subscriber):
    if subscriber and subscriber.age >= 18 and subscriber.id_proof:
        return True
    return False

def has_active_connection(subscriber_id):
    for conn in DATASTORE["connections"].values():
        if conn.subscriber.person_id == subscriber_id and conn.status == "ACTIVE":
            return True
    return False

def positive_int(value):
    try:
        val = int(value)
        return val if val > 0 else None
    except (ValueError, TypeError):
        return None
    