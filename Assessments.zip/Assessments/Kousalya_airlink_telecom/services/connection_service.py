from data.datastore import DATASTORE
from models.connection import Connection
from utils.validator import is_eligible, has_active_connection

class ConnectionService:
    def activate(self, sub_id, plan_id, months):
        sub = DATASTORE["subscribers"].get(sub_id)
        plan = DATASTORE["plans"].get(plan_id)

        if not sub or not plan:
            return None
        if not is_eligible(sub):
            return None
        if has_active_connection(sub_id):
            return None

        total_cost = plan.bill(months) + plan.activation_fee
        if sub.deduct(total_cost):
            conn = Connection(sub, plan, months, total_cost)
            DATASTORE["connections"][conn.connection_id] = conn
            return conn
        return None

    def deactivate(self, conn_id, used_months, port_out=False):
        conn = DATASTORE["connections"].get(conn_id)
        if not conn or conn.status != "ACTIVE":
            return False

        unused_months = conn.months - used_months
        base_refund = unused_months * conn.plan.monthly_price * 0.5
        if port_out:
            base_refund -= 150
            setattr(conn, "port_out_note", "Ported out to another network")

        refund = max(0.0, base_refund)
        conn.subscriber.recharge(refund)
        conn.status = "DEACTIVATED"
        return True

    def get_connection(self, conn_id):
        return DATASTORE["connections"].get(conn_id)

    def list_connections(self):
        return list(DATASTORE["connections"].values())

    def delete_connection(self, conn_id):
        if conn_id in DATASTORE["connections"]:
            del DATASTORE["connections"][conn_id]
            return True
        return False