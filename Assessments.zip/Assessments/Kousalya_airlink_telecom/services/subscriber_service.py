from data.datastore import DATASTORE
from models.subscriber import Subscriber

class SubscriberService:
    def add_subscriber(self, person_id, name, age, phone, id_proof, balance=0.0):
        sub = Subscriber(person_id, name, age, phone, id_proof, balance)
        DATASTORE["subscribers"][person_id] = sub
        return sub

    def get_subscriber(self, person_id):
        return DATASTORE["subscribers"].get(person_id)

    def list_subscribers(self):
        return list(DATASTORE["subscribers"].values())

    def update_phone(self, person_id, new_phone):
        sub = self.get_subscriber(person_id)
        if sub:
            sub.phone = new_phone
            return True
        return False

    def delete_subscriber(self, person_id):
        if person_id in DATASTORE["subscribers"]:
            del DATASTORE["subscribers"][person_id]
            return True
        return False