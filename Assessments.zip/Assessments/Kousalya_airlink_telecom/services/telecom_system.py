from services.subscriber_service import SubscriberService
from services.plan_service import PlanService
from services.connection_service import ConnectionService

class TelecomSystem:
    def __init__(self):
        self.sub_service = SubscriberService()
        self.plan_service = PlanService()
        self.conn_service = ConnectionService()

    def register_subscriber(self, person_id, name, age, phone, id_proof, balance):
        return self.sub_service.add_subscriber(person_id, name, age, phone, id_proof, balance)

    def add_plan(self, plan_type, name, data_per_day, monthly_price):
        return self.plan_service.add_plan(plan_type, name, data_per_day, monthly_price)

    def view_plans_sorted(self):
        plans = self.plan_service.list_plans()
        return sorted(plans)

    def activate_connection(self, sub_id, plan_id, months):
        return self.conn_service.activate(sub_id, plan_id, months)

    def deactivate_connection(self, conn_id, used_months, port_out=False):
        return self.conn_service.deactivate(conn_id, used_months, port_out)

    def view_connections(self):
        return self.conn_service.list_connections()