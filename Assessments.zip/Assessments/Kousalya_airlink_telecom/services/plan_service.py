from data.datastore import DATASTORE
from models.plan import Prepaid, Postpaid, DataPack

class PlanService:
    def add_plan(self, plan_type, name, data_per_day, monthly_price):
        plan_type = plan_type.lower()
        if plan_type == "prepaid":
            plan = Prepaid(name, data_per_day, monthly_price)
        elif plan_type == "postpaid":
            plan = Postpaid(name, data_per_day, monthly_price)
        elif plan_type == "datapack":
            plan = DataPack(name, data_per_day, monthly_price)
        else:
            raise ValueError("Invalid plan type.")
        
        DATASTORE["plans"][plan.plan_id] = plan
        return plan

    def get_plan(self, plan_id):
        return DATASTORE["plans"].get(plan_id)

    def list_plans(self):
        return list(DATASTORE["plans"].values())

    def delete_plan(self, plan_id):
        if plan_id in DATASTORE["plans"]:
            del DATASTORE["plans"][plan_id]
            return True
        return False

    def apply_festival_offer(self, plan_id, pct):
        plan = self.get_plan(plan_id)
        if plan:
            setattr(plan, "festival_offer", pct)
            return True
        return False