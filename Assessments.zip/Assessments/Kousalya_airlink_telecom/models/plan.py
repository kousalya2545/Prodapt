class Plan:
    company ="AirLink"
    id_prefix ="PLAN-"
    activation_fee = 0.0
    _id_counter= 101

    def __init__(self, name, data_per_day, monthly_price, plan_id=None):
        if plan_id:
            self.plan_id = plan_id
        else:
            self.plan_id = f"{self.id_prefix}{Plan._id_counter}"
            Plan._id_counter += 1
        self.name = name
        self.data_per_day = data_per_day
        self.monthly_price = monthly_price

    @property
    def monthly_price(self):
        return self._monthly_price

    @monthly_price.setter
    def monthly_price(self, value):
        if value <= 0:
            raise ValueError("Monthly price must be greater than 0.")
        self._monthly_price = float(value)

    def bill(self, months):
        offer = getattr(self, "festival_offer", 0)
        base_bill = self.monthly_price * months
        discount = base_bill * (offer / 100.0)
        return base_bill - discount

    def __eq__(self, other):
        if isinstance(other, Plan):
            return self.plan_id == other.plan_id
        return False

    def __lt__(self, other):
        if isinstance(other, Plan):
            return self.monthly_price < other.monthly_price
        return NotImplemented

    def __str__(self):
        return f"{self.plan_id} | {self.name} | Price: ₹{self.monthly_price:.2f}/mo | Data: {self.data_per_day}"


class Prepaid(Plan):
    id_prefix = "PRE-"
    activation_fee = 0.0

    def bill(self, months):
        return super().bill(months)


class Postpaid(Plan):
    id_prefix = "POST-"
    activation_fee = 100.0

    def bill(self, months):
        base_bill = super().bill(months)
        return base_bill * 1.18


class DataPack(Plan):
    id_prefix = "DATA-"
    activation_fee = 50.0

    def bill(self, months):
        base_bill = super().bill(months)
        return base_bill + 50.0
    