from models.person import Person

class Subscriber(Person):
    def __init__(self, person_id, name, age, phone, id_proof, balance=0.0):
        super().__init__(person_id, name, age, phone)
        self.id_proof = id_proof
        self.__balance = float(balance)

    @property
    def balance(self):
        return self.__balance

    def recharge(self, amount):
        if amount > 0:
            self.__balance += amount
            return True
        return False

    def deduct(self, amount):
        if 0 < amount <= self.__balance:
            self.__balance -= amount
            return True
        return False

    def __str__(self):
        return f"Subscriber[{self.person_id}]: {self.name}, Balance: ₹{self.__balance:.2f}"
    
    