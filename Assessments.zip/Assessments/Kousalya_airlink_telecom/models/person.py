class Person:
    def __init__(self, person_id, name, age, phone):
        self.person_id = person_id
        self.name = name
        self.age = age
        self.phone = phone
        