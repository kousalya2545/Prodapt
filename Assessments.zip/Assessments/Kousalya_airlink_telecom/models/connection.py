class Connection:
    _id_counter = 9001

    def __init__(self, subscriber, plan, months, amount_paid, connection_id=None):
        if connection_id:
            self.connection_id = connection_id
        else:
            self.connection_id = Connection._id_counter
            Connection._id_counter += 1
        self.subscriber = subscriber
        self.plan = plan
        self.months = months
        self.amount_paid = amount_paid
        self.status = "ACTIVE"

    def __str__(self):
        return f"Conn #{self.connection_id} | Sub: {self.subscriber.name} | Plan: {self.plan.name} | Status: {self.status} | Paid: ₹{self.amount_paid:.2f}"

    def __del__(self):
        print(f"[ARCHIVE] Connection #{getattr(self, 'connection_id', 'N/A')} closed")