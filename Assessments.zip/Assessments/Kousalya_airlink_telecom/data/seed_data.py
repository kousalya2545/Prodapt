from data.datastore import DATASTORE
from models.subscriber import Subscriber
from models.plan import Prepaid, Postpaid, DataPack

def seed_database():
    p1 = Prepaid("Smart Saver", "1GB/day", 200, plan_id="PRE-101")
    p2 = Postpaid("Business Pro", "3GB/day", 500, plan_id="POST-201")
    p3 = DataPack("NetMax 2GB/day", "2GB/day", 300, plan_id="DATA-301")

    s1 = Subscriber("SUB01", "Karthik", 26, "9876543210", "AAD-4821-9034", balance=2000)
    s2 = Subscriber("SUB02", "Divya", 34, "9876543211", "AAD-7733-1268", balance=5000)
    s3 = Subscriber("SUB03", "Vimal", 16, "9876543212", None, balance=500)

    DATASTORE["plans"][p1.plan_id] = p1
    DATASTORE["plans"][p2.plan_id] = p2
    DATASTORE["plans"][p3.plan_id] = p3

    DATASTORE["subscribers"][s1.person_id] = s1
    DATASTORE["subscribers"][s2.person_id] = s2
    DATASTORE["subscribers"][s3.person_id] = s3