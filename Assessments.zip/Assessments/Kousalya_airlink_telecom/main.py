import sys
from data.seed_data import seed_database
from services.telecom_system import TelecomSystem
from utils.validator import positive_int

def main():
    seed_database()
    system = TelecomSystem()

    while True:
        print("\n======= AIRLINK TELECOM PORTAL =======")
        print("1. Register subscriber")
        print("2. Add plan")
        print("3. View plans (sorted by price)")
        print("4. Activate a connection")
        print("5. Deactivate a connection")
        print("6. View connections")
        print("7. Exit")

        choice = input("Enter choice (1-7): ").strip()

        if choice == "1":
            sub_id = input("Enter Subscriber ID (e.g. SUB04): ").strip()
            name = input("Enter Name: ").strip()
            try:
                age = int(input("Enter Age: ").strip())
            except ValueError:
                print("Invalid age.")
                continue
            phone = input("Enter Phone: ").strip()
            id_proof = input("Enter ID Proof (press enter if none): ").strip() or None
            try:
                balance = float(input("Enter Initial Balance: ").strip())
            except ValueError:
                print("Invalid balance.")
                continue
            sub = system.register_subscriber(sub_id, name, age, phone, id_proof, balance)
            print(f"Registered successfully: {sub}")

        elif choice == "2":
            ptype = input("Enter Plan Type (prepaid/postpaid/datapack): ").strip()
            name = input("Enter Plan Name: ").strip()
            data = input("Enter Data per day (e.g. 1.5GB/day): ").strip()
            try:
                price = float(input("Enter Monthly Price: ").strip())
                plan = system.add_plan(ptype, name, data, price)
                print(f"Plan added: {plan}")
            except ValueError as e:
                print(f"Error adding plan: {e}")

        elif choice == "3":
            plans = system.view_plans_sorted()
            print("\n--- Available Plans (Sorted by Price) ---")
            for p in plans:
                print(p)

        elif choice == "4":
            sub_id = input("Enter Subscriber ID: ").strip()
            plan_id = input("Enter Plan ID: ").strip()
            months = positive_int(input("Enter Months: ").strip())
            if not months:
                print("Invalid number of months.")
                continue
            conn = system.activate_connection(sub_id, plan_id, months)
            if conn:
                print(f"Connection activated successfully: {conn}")
            else:
                print("Activation failed! (Check eligibility, balance, or existing active connections)")

        elif choice == "5":
            try:
                conn_id = int(input("Enter Connection ID: ").strip())
                used_months = int(input("Enter Months Used: ").strip())
            except ValueError:
                print("Invalid input.")
                continue
            port_str = input("Porting out? (y/n): ").strip().lower()
            port_out = port_str == "y"
            success = system.deactivate_connection(conn_id, used_months, port_out)
            if success:
                print("Connection deactivated successfully.")
            else:
                print("Deactivation failed.")

        elif choice == "6":
            conns = system.view_connections()
            print("\n--- All Connections ---")
            for c in conns:
                print(c)

        elif choice == "7":
            print("Exiting application...")
            sys.exit(0)

        else:
            print("Invalid option. Please try again.")

if __name__ == "__main__":
    main()