import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from data.datastore import DATASTORE  # type: ignore[import]
from services.customer_service import CustomerService  # type: ignore[import]
from models.customer import Customer  # type: ignore[import]

class TestCustomer(unittest.TestCase):
    def setUp(self):
        DATASTORE["customers"].clear()
        DATASTORE["vehicles"].clear()
        DATASTORE["rentals"].clear()
        self.service = CustomerService()

    def test_add_customer(self):
        cust = self.service.add_customer("CU01", "Arjun", 24, "9876543210", "TN10-2021-0042", 5000)
        self.assertIn("CU01", DATASTORE["customers"])
        self.assertEqual(DATASTORE["customers"]["CU01"].name, "Arjun")

    def test_wallet_encapsulation(self):
        cust = Customer("CU01", "Arjun", 24, "9876543210", "TN10-2021-0042", 5000)
        result = cust.pay(6000)
        self.assertFalse(result)
        self.assertEqual(cust.balance, 5000)
        with self.assertRaises(AttributeError):
            _ = cust.__wallet