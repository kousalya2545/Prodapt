import unittest
from data.datastore import DATASTORE  # type: ignore
from services.rental_system import RentalSystem  # type: ignore

class TestRental(unittest.TestCase):
    def setUp(self):
        DATASTORE["customers"].clear()
        DATASTORE["vehicles"].clear()
        DATASTORE["rentals"].clear()
        self.system = RentalSystem()

    def test_rent_success(self):
        cust = self.system.register_customer("CU01", "Arjun", 24, "9876543210", "TN10-2021-0042", 5000)
        veh = self.system.add_vehicle("bike", "Honda Activa", 400)
        
        rental, msg = self.system.rent_vehicle(cust.person_id, veh.vehicle_id, 2)
        
        self.assertIsNotNone(rental)
        self.assertIn(rental.rental_id, DATASTORE["rentals"])
        self.assertFalse(veh.available)
        self.assertEqual(cust.balance, 3800)

    def test_ineligible_blocked(self):
        cust = self.system.register_customer("CU03", "Rahul", 17, "9876543212", None, 2000)
        veh = self.system.add_vehicle("bike", "Honda Activa", 400)

        rental, msg = self.system.rent_vehicle(cust.person_id, veh.vehicle_id, 2)

        self.assertIsNone(rental)
        self.assertEqual(len(DATASTORE["rentals"]), 0)
        self.assertTrue(veh.available)