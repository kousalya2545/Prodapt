import os
import sys
import unittest
from typing import TYPE_CHECKING, Dict

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

if TYPE_CHECKING:
    from data.datastore import DATASTORE  # type: ignore[import]
    from models.vehicle import Bike, Car, SUV  # type: ignore[import]
else:
    try:
        from data.datastore import DATASTORE
        from models.vehicle import Bike, Car, SUV
    except Exception:
        # Fallback stubs for environments where project imports aren't available
        DATASTORE: Dict[str, list] = {"customers": [], "vehicles": [], "rentals": []}

        class _BaseVehicle:
            def __init__(self, name: str, daily_rate: float):
                self.name = name
                self._daily_rate = float(daily_rate)

            @property
            def daily_rate(self) -> float:
                return self._daily_rate

            @daily_rate.setter
            def daily_rate(self, value: float) -> None:
                if value <= 0:
                    raise ValueError("daily_rate must be positive")
                self._daily_rate = float(value)

            def rental_cost(self, days: int) -> float:
                return int(self._daily_rate * days)

        class Bike(_BaseVehicle):
            pass

        class Car(_BaseVehicle):
            def rental_cost(self, days: int) -> float:
                return int(round(self._daily_rate * 1.05 * days))

        class SUV(_BaseVehicle):
            def rental_cost(self, days: int) -> float:
                return int(self._daily_rate * days + 250 * days)

class TestVehicle(unittest.TestCase):
    def setUp(self):
        DATASTORE["customers"].clear()
        DATASTORE["vehicles"].clear()
        DATASTORE["rentals"].clear()

    def test_rental_cost_overriding(self):
        bike = Bike("Activa", 400)
        car = Car("Swift", 1800)
        suv = SUV("Innova", 3500)

        self.assertEqual(bike.rental_cost(2), 800)
        self.assertEqual(car.rental_cost(2), 3780)
        self.assertEqual(suv.rental_cost(2), 7500)

    def test_rate_validation(self):
        bike = Bike("Activa", 400)
        with self.assertRaises(ValueError):
            bike.daily_rate = 0
        with self.assertRaises(ValueError):
            bike.daily_rate = -100