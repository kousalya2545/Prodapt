import sys
from data.seed_data import load_seed_data
from services.rental_system import RentalSystem
from utils.validator import positive_int

def main():
    load_seed_data()
    system = RentalSystem()

    while True:
        print("\n====== QUICKWHEELS VEHICLE RENTAL ======")
        print("1. Register customer")
        print("2. Add vehicle")
        print("3. View vehicles (sorted by rate)")
        print("4. Rent a vehicle")
        print("5. Return a vehicle")
        print("6. View rentals")
        print("7. Exit (archive rentals -> destructors fire)")
        
        choice = input("Enter choice (1-7): ").strip()

        if choice == "1":
            cust_id = input("Enter Customer ID (e.g. CU04): ").strip()
            name = input("Enter Name: ").strip()
            age = positive_int(input("Enter Age: "))
            if not age:
                print("Invalid age.")
                continue
            phone = input("Enter Phone: ").strip()
            license_no = input("Enter License Number (leave empty if none): ").strip() or None
            try:
                wallet = float(input("Enter Initial Wallet Balance: "))
            except ValueError:
                print("Invalid balance amount.")
                continue

            system.register_customer(cust_id, name, age, phone, license_no, wallet)
            print("Customer registered successfully.")

        elif choice == "2":
            v_type = input("Enter Vehicle Type (Bike/Car/SUV): ").strip()
            name = input("Enter Vehicle Name: ").strip()
            try:
                rate = float(input("Enter Daily Rate: "))
                vehicle = system.add_vehicle(v_type, name, rate)
                print(f"Vehicle added successfully! Generated ID: {vehicle.vehicle_id}")
            except ValueError as e:
                print(f"Error adding vehicle: {e}")

        elif choice == "3":
            vehicles = system.view_vehicles()
            print("\n--- Available & Rented Vehicles (Sorted by Rate) ---")
            for v in vehicles:
                print(v)

        elif choice == "4":
            cust_id = input("Enter Customer ID: ").strip()
            veh_id = input("Enter Vehicle ID: ").strip()
            days = positive_int(input("Enter Rental Days: "))
            if not days:
                print("Invalid number of days.")
                continue

            rental, msg = system.rent_vehicle(cust_id, veh_id, days)
            if rental:
                print(f"\nSuccess! Rental Created:\n{rental}")
            else:
                print(f"\nFailed to Rent: {msg}")

        elif choice == "5":
            r_id = positive_int(input("Enter Rental ID (e.g. 5001): "))
            if not r_id:
                print("Invalid Rental ID.")
                continue
            actual_days = positive_int(input("Enter Actual Days Used: "))
            if not actual_days:
                print("Invalid days count.")
                continue
            has_damage = input("Any damage? (y/n): ").strip().lower()
            damage_note = None
            if has_damage == 'y':
                damage_note = input("Enter damage description: ").strip()

            rental, msg = system.return_vehicle(r_id, actual_days, damage_note)
            print(f"\n{msg}")

        elif choice == "6":
            rentals = system.view_rentals()
            if not rentals:
                print("\nNo rentals found.")
            else:
                print("\n--- All Rentals ---")
                for r in rentals:
                    print(r)
                    print("-" * 30)

        elif choice == "7":
            print("\nExiting system...")
            from data.datastore import DATASTORE
            DATASTORE["rentals"].clear()
            sys.exit(0)

        else:
            print("Invalid option. Please choose between 1 and 7.")

if __name__ == "__main__":
    main()