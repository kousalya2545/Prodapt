from data.datastore import DATASTORE
from models.customer import Customer
from models.vehicle import Bike, Car, SUV

def load_seed_data():
    b1 = Bike("Honda Activa", 400)
    b1.vehicle_id = "B-101"
    
    c1 = Car("Maruti Swift", 1800)
    c1.vehicle_id = "C-201"
    
    s1 = SUV("Toyota Innova", 3500)
    s1.vehicle_id = "S-301"

    DATASTORE["vehicles"][b1.vehicle_id] = b1
    DATASTORE["vehicles"][c1.vehicle_id] = c1
    DATASTORE["vehicles"][s1.vehicle_id] = s1

    c1_cust = Customer("CU01", "Arjun", 24, "9876543210", "TN10-2021-0042", 5000)
    c2_cust = Customer("CU02", "Meera", 31, "9876543211", "TN22-2018-0913", 15000)
    c3_cust = Customer("CU03", "Rahul", 17, "9876543212", None, 2000)

    DATASTORE["customers"][c1_cust.person_id] = c1_cust
    DATASTORE["customers"][c2_cust.person_id] = c2_cust
    DATASTORE["customers"][c3_cust.person_id] = c3_cust