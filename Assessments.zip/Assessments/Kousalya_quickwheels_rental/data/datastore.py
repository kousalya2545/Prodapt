DATASTORE = {
    "customers": {},
    "vehicles": {},
    "rentals": {}
}