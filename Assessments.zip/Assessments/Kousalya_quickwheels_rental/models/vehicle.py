class Vehicle:
    company = "QuickWheels"
    id_prefix = "V-"
    deposit_days = 0
    _auto_id_counter = 100

    def __init__(self, name, daily_rate):
        Vehicle._auto_id_counter += 1
        self.vehicle_id = f"{self.id_prefix}{Vehicle._auto_id_counter}"
        self.name = name
        self._daily_rate = 0.0
        self.daily_rate = daily_rate
        self.available = True

    @property
    def daily_rate(self):
        return self._daily_rate

    @daily_rate.setter
    def daily_rate(self, value):
        if value <= 0:
            raise ValueError("Daily rate must be greater than zero.")
        self._daily_rate = float(value)

    def rental_cost(self, days):
        return self.daily_rate * days

    def __eq__(self, other):
        if isinstance(other, Vehicle):
            return self.vehicle_id == other.vehicle_id
        return False

    def __lt__(self, other):
        if isinstance(other, Vehicle):
            return self.daily_rate < other.daily_rate
        return NotImplemented

    def __str__(self):
        return f"[{self.vehicle_id}] {self.name} - ₹{self.daily_rate}/day ({'Available' if self.available else 'Rented'})"


class Bike(Vehicle):
    id_prefix = "B-"
    deposit_days = 1

    def rental_cost(self, days):
        return self.daily_rate * days


class Car(Vehicle):
    id_prefix = "C-"
    deposit_days = 2

    def rental_cost(self, days):
        return self.daily_rate * days * 1.05


class SUV(Vehicle):
    id_prefix = "S-"
    deposit_days = 3

    def rental_cost(self, days):
        return (self.daily_rate * days) + 500