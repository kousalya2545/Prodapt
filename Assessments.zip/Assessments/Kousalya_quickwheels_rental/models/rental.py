class Rental:
    _id_counter = 5001

    def __init__(self, customer, vehicle, planned_days, amount_paid, deposit):
        self.rental_id = Rental._id_counter
        Rental._id_counter += 1
        self.customer = customer
        self.vehicle = vehicle
        self.planned_days = planned_days
        self.amount_paid = amount_paid
        self.deposit = deposit
        self.status = "ACTIVE"

    def __str__(self):
        damage_info = f"\nDamage Note: {getattr(self, 'damage_note')}" if hasattr(self, 'damage_note') else ""
        return (f"Rental #{self.rental_id} | Status: {self.status}\n"
                f"Customer: {self.customer.name} ({self.customer.person_id})\n"
                f"Vehicle: {self.vehicle.name} ({self.vehicle.vehicle_id})\n"
                f"Planned Days: {self.planned_days} | Amount Paid: ₹{self.amount_paid} | Deposit: ₹{self.deposit}"
                f"{damage_info}")

    def __del__(self):
        print(f"[ARCHIVE] Rental #{getattr(self, 'rental_id', 'Unknown')} closed")