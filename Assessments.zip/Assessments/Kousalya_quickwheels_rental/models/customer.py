from models.person import Person

class Customer(Person):
    def __init__(self, person_id, name, age, phone, license_no, initial_wallet=0.0):
        super().__init__(person_id, name, age, phone)
        self.license_no = license_no
        self.__wallet = float(initial_wallet)

    @property
    def balance(self):
        return self.__wallet

    def add_money(self, amount):
        if amount > 0:
            self.__wallet += amount

    def pay(self, amount):
        if amount <= self.__wallet:
            self.__wallet -= amount
            return True
        return False