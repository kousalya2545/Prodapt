from data.datastore import DATASTORE
from models.customer import Customer

class CustomerService:
    def add_customer(self, cust_id, name, age, phone, license_no, initial_wallet):
        customer = Customer(cust_id, name, age, phone, license_no, initial_wallet)
        DATASTORE["customers"][cust_id] = customer
        return customer

    def get_customer(self, cust_id):
        return DATASTORE["customers"].get(cust_id)

    def list_customers(self):
        return list(DATASTORE["customers"].values())

    def update_phone(self, cust_id, new_phone):
        customer = self.get_customer(cust_id)
        if customer:
            customer.phone = new_phone
            return True
        return False

    def delete_customer(self, cust_id):
        if cust_id in DATASTORE["customers"]:
            del DATASTORE["customers"][cust_id]
            return True
        return False