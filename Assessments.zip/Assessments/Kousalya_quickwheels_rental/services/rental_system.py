from services.customer_service import CustomerService
from services.vehicle_service import VehicleService
from services.rental_service import RentalService

class RentalSystem:
    def __init__(self):
        self.customer_service = CustomerService()
        self.vehicle_service = VehicleService()
        self.rental_service = RentalService()

    def register_customer(self, cust_id, name, age, phone, license_no, initial_wallet):
        return self.customer_service.add_customer(cust_id, name, age, phone, license_no, initial_wallet)

    def add_vehicle(self, v_type, name, daily_rate):
        return self.vehicle_service.add_vehicle(v_type, name, daily_rate)

    def view_vehicles(self):
        return self.vehicle_service.list_vehicles()

    def rent_vehicle(self, cust_id, veh_id, days):
        return self.rental_service.rent(cust_id, veh_id, days)

    def return_vehicle(self, rental_id, actual_days, damage_note=None):
        return self.rental_service.return_vehicle(rental_id, actual_days, damage_note)

    def view_rentals(self):
        return self.rental_service.list_rentals()