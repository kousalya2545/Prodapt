from data.datastore import DATASTORE
from models.rental import Rental
from utils.validator import is_eligible, is_available

class RentalService:
    def rent(self, cust_id, veh_id, days):
        customer = DATASTORE["customers"].get(cust_id)
        vehicle = DATASTORE["vehicles"].get(veh_id)

        if not customer or not vehicle:
            return None, "Customer or Vehicle not found."

        if not is_eligible(customer):
            return None, "Customer is not eligible to rent."

        if not is_available(vehicle):
            return None, "Vehicle is currently unavailable."

        base_cost = vehicle.rental_cost(days)
        discount_pct = getattr(vehicle, "festival_offer", 0)
        cost = base_cost * (1 - discount_pct / 100.0)

        deposit = vehicle.daily_rate * vehicle.deposit_days
        total_required = cost + deposit

        if not customer.pay(total_required):
            return None, f"Insufficient balance. Required: ₹{total_required}, Available: ₹{customer.balance}"

        vehicle.available = False
        rental = Rental(customer, vehicle, days, cost, deposit)
        DATASTORE["rentals"][rental.rental_id] = rental

        return rental, "Success"

    def return_vehicle(self, rental_id, actual_days, damage_note=None):
        rental = DATASTORE["rentals"].get(rental_id)
        if not rental or rental.status == "CLOSED":
            return None, "Active rental not found."

        vehicle = rental.vehicle
        extra_days = max(0, actual_days - rental.planned_days)
        late_fee = extra_days * vehicle.daily_rate * 1.5

        damage_fine = 1000.0 if damage_note else 0.0
        total_charges = late_fee + damage_fine

        refund = max(0.0, rental.deposit - total_charges)
        rental.customer.add_money(refund)

        vehicle.available = True
        rental.status = "CLOSED"

        if damage_note:
            setattr(rental, "damage_note", damage_note)

        return rental, f"Vehicle returned. Refunded to wallet: ₹{refund}"

    def get_rental(self, rental_id):
        return DATASTORE["rentals"].get(rental_id)

    def list_rentals(self):
        return list(DATASTORE["rentals"].values())

    def delete_rental(self, rental_id):
        if rental_id in DATASTORE["rentals"]:
            del DATASTORE["rentals"][rental_id]
            return True
        return False