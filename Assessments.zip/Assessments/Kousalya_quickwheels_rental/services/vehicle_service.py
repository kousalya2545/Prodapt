from data.datastore import DATASTORE
from models.vehicle import Bike, Car, SUV

class VehicleService:
    def add_vehicle(self, v_type, name, daily_rate):
        v_type = v_type.lower()
        if v_type == "bike":
            vehicle = Bike(name, daily_rate)
        elif v_type == "car":
            vehicle = Car(name, daily_rate)
        elif v_type == "suv":
            vehicle = SUV(name, daily_rate)
        else:
            raise ValueError("Invalid vehicle type")
        DATASTORE["vehicles"][vehicle.vehicle_id] = vehicle
        return vehicle

    def get_vehicle(self, veh_id):
        return DATASTORE["vehicles"].get(veh_id)

    def list_vehicles(self):
        return sorted(list(DATASTORE["vehicles"].values()))

    def apply_festival_offer(self, veh_id, pct):
        vehicle = self.get_vehicle(veh_id)
        if vehicle:
            setattr(vehicle, "festival_offer", pct)
            return True
        return False

    def delete_vehicle(self, veh_id):
        if veh_id in DATASTORE["vehicles"]:
            del DATASTORE["vehicles"][veh_id]
            return True
        return False