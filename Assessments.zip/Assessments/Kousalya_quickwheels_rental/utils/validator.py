def is_eligible(customer):
    if customer.age >= 18 and customer.license_no:
        return True
    return False

def is_available(vehicle):
    return vehicle.available

def positive_int(val):
    try:
        val = int(val)
        return val if val > 0 else None
    except (ValueError, TypeError):
        return None