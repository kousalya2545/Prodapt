from models.product import Product


class StoreService:

    def __init__(self):
        self.products = []

    def add_product(self, name, price, stock):

        product = Product(name, price, stock)

        self.products.append(product)

    def display_products(self):

        print("\nAvailable Products\n")

        for i, product in enumerate(self.products, 1):
            print(i, product)

    def get_product(self, index):

        return self.products[index]