import unittest

from models.product import Product
from models.cart import Cart


class TestCart(unittest.TestCase):

    def test_add_product(self):

        cart = Cart()

        laptop = Product("Laptop", 50000, 5)

        cart.add_product(laptop, 1)

        self.assertEqual(len(cart.items), 1)

    def test_total(self):

        cart = Cart()

        laptop = Product("Laptop", 50000, 5)

        cart.add_product(laptop, 2)

        self.assertEqual(cart.calculate_total(), 100000)


if __name__ == "__main__":
    unittest.main()