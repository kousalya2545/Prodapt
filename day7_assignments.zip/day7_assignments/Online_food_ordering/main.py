from services.store_service import StoreService
from services.cart_service import CartService

from models.user import User
from models.premium_user import PremiumUser

from utils.file_handler import save_order

store = StoreService()

store.add_product("Laptop", 60000, 5)
store.add_product("Mouse", 500, 20)
store.add_product("Keyboard", 1200, 15)

store.display_products()

print()

user = PremiumUser("Alice")

product1 = store.get_product(0)
product2 = store.get_product(1)

user.cart.add_product(product1, 1)
user.cart.add_product(product2, 2)

user.cart.view_cart()

print()

print("Discounted Bill = ₹", user.final_bill())

save_order(user.cart)

checkout = CartService()

checkout.checkout(user)
