from models.user import User


class PremiumUser(User):

    def __init__(self, name):
        super().__init__(name)

    def get_discount(self):
        return 10

    def final_bill(self):

        total = self.cart.calculate_total()

        discount = total * self.get_discount() / 100

        return total - discount