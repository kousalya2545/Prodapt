from models.cart import Cart


class User:

    def __init__(self, name):
        self.name = name
        self.cart = Cart()

    def display(self):
        print("Customer :", self.name)